def sayhello():
    print 'Hello world! This is my module.'

print "I'm done."
# end of module